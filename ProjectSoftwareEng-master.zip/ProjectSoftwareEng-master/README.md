# ProjectSoftwareEng

<b>Goal</b>: Develop an application implementing a geometric drawing program

## Group 16 Members

* Iannaccone Martina
 
* Ricciardi Andrea Vincenzo
 
* Rolando Giovanni

## Links

* [Trello](https://trello.com/b/XJnZBVnG/group16softwareeng)

* [Excel](https://docs.google.com/spreadsheets/d/e/2PACX-1vRMcaPpx2Poh_Vxo-SeMj47TycSukkJ44vhRATRumu_Lr6ifiSudwzSv3CqM_AvoiKS6sZ0RxydDLiW/pubhtml)

## UML

![group16](https://user-images.githubusercontent.com/116253755/207160429-5f86667c-21fb-4aa1-8a3f-5f11c19a3b44.png)

## DEMO

https://user-images.githubusercontent.com/118052231/209473917-07c9d4f2-5bb8-489f-abc3-32e1efcf2c49.mp4

